import json
import boto3
import base64
import datetime
from botocore.exceptions import ClientError

# Initialize AWS clients
s3_client = boto3.client('s3')
# bedrock_client = boto3.client('bedrock-runtime', region_name="eu-west-2")  # IMPORTANT
# bedrock_client = boto3.client('bedrock-runtime', region_name="us-west-2")
# session = boto3.session.Session(region_name="us-west-2")

session = boto3.session.Session(region_name="us-west-2")

bedrock_client = session.client(
    service_name="bedrock-runtime",
    region_name="us-west-2",
    endpoint_url="https://bedrock-runtime.us-west-2.amazonaws.com",
    config=boto3.session.Config(
        region_name="us-west-2",
        signature_version="v4"
    )
)




def lambda_handler(event, context):
    try:
        # Ensure 'httpMethod' exists in the event
        if 'httpMethod' not in event:
            return {
                'statusCode': 400,
                'body': json.dumps('Invalid request: Missing httpMethod. Ensure this function is invoked via API Gateway.')
            }

        # Parse API Gateway request
        if event['httpMethod'] == 'GET':
            return {
                'statusCode': 400,
                'body': json.dumps('GET method is not supported. Use POST.')
            }
        
        if 'body' not in event:
            return {
                'statusCode': 400,
                'body': json.dumps('Invalid request: Missing body.')
            }

        body = json.loads(event['body'])
        bucket_name = body.get('bucket_name')
        object_key = body.get('object_key')

        if not bucket_name or not object_key:
            return {
                'statusCode': 400,
                'body': json.dumps('Invalid request: bucket_name and object_key are required.')
            }

        # Read the image from S3
        image_data = read_image_from_s3(bucket_name, object_key)

        # Send the image to Amazon Bedrock multimodal model
        analysis_result = analyze_image_with_bedrock(image_data)

        # Generate a new image name
        new_object_key = generate_new_image_name(object_key)

        # Save the original image with the new name in the same S3 bucket
        save_image_to_s3(bucket_name, new_object_key, image_data)

        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Image processed successfully.',
                'new_image_key': new_object_key,
                'analysis_result': analysis_result
            })
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error: {str(e)}")
        }
    
def read_image_from_s3(bucket_name, object_key):
    """Read an image from S3."""
    try:
        response = s3_client.get_object(Bucket=bucket_name, Key=object_key)
        return response['Body'].read()
    except ClientError as e:
        raise Exception(f"Failed to read image from S3: {str(e)}")


def analyze_image_with_bedrock(image_data):
    """Send the image to Amazon Bedrock Nova Pro model for analysis."""
    base64_image = base64.b64encode(image_data).decode("utf-8")

    # CORRECT Nova Pro payload
    payload = {
        "inputText": "Analyze this image and describe all visible objects.",
        "inputImage": base64_image
    }

    response = bedrock_client.invoke_model(
        # modelId="amazon.nova-pro-v1:0",  # CORRECT MODEL ID
        # modelId="arn:aws:bedrock:us-west-2::foundation-model/amazon.nova-pro-v1:0",  # Replace with the correct model ID
        modelId="arn:aws:bedrock:us-west-2:371456644911:application-inference-profile/ogwts3z2qscb",
        contentType="application/json",
        accept="application/json",
        body=json.dumps(payload)
    )

    return json.loads(response["body"].read().decode("utf-8"))


def generate_new_image_name(object_key):
    """Generate a new image name by appending a timestamp."""
    timestamp = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
    file_extension = object_key.split('.')[-1]
    base_name = '.'.join(object_key.split('.')[:-1])
    return f"{base_name}-processed-{timestamp}.{file_extension}"

def save_image_to_s3(bucket_name, object_key, image_data):
    """Save the image to S3 with a new name."""
    try:
        s3_client.put_object(Bucket=bucket_name, Key=object_key, Body=image_data)
    except ClientError as e:
        raise Exception(f"Failed to save image to S3: {str(e)}")
