import json
import boto3

bedrock = boto3.client(
    service_name="bedrock-runtime",
    region_name="us-west-2"
)

MODEL_ARN = "arn:aws:bedrock:us-west-2:371456644911:application-inference-profile/klrvf9i3t2u2"

def lambda_handler(event, context):
    try:
        body = json.loads(event.get("body", "{}"))
        user_message = body.get("message", "Hello")

        # ✔ Correct payload schema
        payload = {
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "text": user_message
                        }
                    ]
                }
            ]
        }

        response = bedrock.invoke_model_with_response_stream(
            modelId=MODEL_ARN,
            contentType="application/json",
            accept="application/json",
            body=json.dumps(payload)
        )

        final_text = ""

        # ✔ Extract only assistant text from streaming events
        for event in response.get("body"):
            chunk = event.get("chunk")
            if not chunk:
                continue

            decoded = chunk.get("bytes").decode("utf-8")

            try:
                obj = json.loads(decoded)

                # Only process contentBlockDelta events
                if "contentBlockDelta" in obj:
                    delta = obj["contentBlockDelta"]["delta"]
                    if "text" in delta:
                        final_text += delta["text"]

            except:
                # Ignore non‑JSON chunks
                pass

        return {
            "statusCode": 200,
            "body": json.dumps({"reply": final_text})
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
